//
//  Environment.swift
//  AgentDemo1
//
//  Created by Loren Olson on 11/1/17.
//  Copyright © 2017 ASU. All rights reserved.
//

import Foundation
import Tin


class Environment {
    
    var food: [TVector2]
    var poison: [TVector2]
    
    init() {
        food = []
        poison = []
    }
    
    
    func addFood() {
        let v = TVector2(x: random(max: tin.width), y: random(max: tin.height))
        food.append(v)
    }
    
    func addPoison() {
        let v = TVector2(x: random(max: tin.width), y: random(max: tin.height))
        poison.append(v)
    }
    
    
    func render() {
        for f in food {
            strokeDisable()
            fillColor(red: 0.1, green: 0.8, blue: 0.1, alpha: 1)
            ellipse(centerX: f.x, centerY: f.y, width: 8, height: 8)
        }
        
        for p in poison {
            strokeDisable()
            fillColor(red: 0.2, green: 0.5, blue: 0.7, alpha: 1)
            rect(x: p.x, y: p.y, width: 30, height: 30)
        }
    }
    
}
