//
//  Vehicle.swift
//  AgentDemo1
//
//  Created by Loren Olson on 10/30/17.
//  Copyright © 2017 ASU. All rights reserved.
//

import Foundation
import Tin

enum Behavior {
    case seek
    case coast
    //Add these
    case flee
    case wander
}

class Vehicle {
    var position: TVector2
    var velocity: TVector2
    var acceleration: TVector2
    var r: Double
    var maxforce: Double
    var maxspeed: Double
    var energy: Double
    var behavior = Behavior.coast
    var wandertheta: Double
    
    init(x: Double, y: Double) {
        acceleration = TVector2()
        let vx = randomGaussian() * 6.0
        let vy = randomGaussian() * 6.0
        velocity = TVector2(x: vx, y: vy)
        position = TVector2(x: x, y: y)
        r = 4.0
        maxspeed = 4.0
        maxforce = 0.1
        energy = 0.0
        wandertheta = 0.0 //in wander func make it a perlin noise and not a random number to get less of a jittery effect.Don't forget to add the drawWanderStuff function.
        /*
         Add a limit --> wandertheta = constraint(value: wandertheta, min: -1.0, max: 1.0)
         */
    }
    
    
    func run(env: Environment) {
        
        behavior = .coast
        
        //Seek
        var closeDistance = 1000000000.0
        var closePosition: TVector2? = nil
        var index = 0
        for f in env.food {
            let d = position.distance(v: f)
            if d < closeDistance {
                closeDistance = d
                closePosition = f
                if d < 4.0 {
                    eat(amount: 250.0)
                    env.food.remove(at: index)
                    index -= 1
                }
                index += 1
            }

            if closeDistance < 150.0 {
                behavior = .seek
                seek(target: closePosition!)
            }
        }
        
        var poisonDistance = 1000000000.0
        var poisonPosition: TVector2? = nil
        for p in env.poison {
            let d1 = position.distance(v: p)
            if d1 < poisonDistance {
                poisonDistance = d1
                poisonPosition = p
            }
            
            if poisonDistance < 150.0 {
                behavior = .flee
                flee(target: poisonPosition!)
            }
        }

        update()
        borders()
        display()
    }


    func eat(amount: Double) {
        energy += amount
    }
    
    func borders() {
        if position.x < -r {
            position.x = tin.width + r
        }
        if position.y < -r {
            position.y = tin.height + r
        }
        if position.x > tin.width + r {
            position.x = -r
        }
        if position.y > tin.height + r {
            position.y = -r
        }
    }
    
    
    func update() {
        velocity = velocity + acceleration
        velocity.limit(mag: maxspeed)
        position = position + velocity
        acceleration = acceleration * 0.0
        energy = 1.0
    }
    
    
    func apply(force: TVector2) {
        acceleration = acceleration + force
    }
    
    
    func seek(target: TVector2) {
        var desired = target - position
        desired.normalize()
        desired = desired * maxspeed
        
        var steer = desired - velocity
        steer.limit(mag: maxforce)
        
        apply(force: steer)
    }
    
    func arrive(target: TVector2) {
        var desired = target - position
        let d = desired.magnitude
        if d < 100.0 {
            let m = remap(value: d, start1: 0.0, stop1: 100.0, start2: 0, stop2: maxspeed)
            desired.magnitude = m
        }
        else {
            desired.magnitude = maxspeed
        }
        
        var steer = desired - velocity
        steer.limit(mag: maxforce)
        
        apply(force: steer)
    }
    
    func flee(target: TVector2) {
        var desired = position - target
        desired.normalize()
        desired = desired * maxspeed
        
        var repel = desired - velocity
        repel.limit(mag: maxforce * 100)
        
        apply(force: repel)
    }
    
    func display() {
        let theta = velocity.heading() + .pi / 2.0
        let c = remap(value: energy, start1: 0.0, stop1: 2000.0, start2: 0.0, stop2: 1.0)
        fillColor(gray: c)
        
        if behavior == .coast {
            lineWidth(1)
             strokeColor(gray: 0.0)
        }
        else if behavior == .seek
        {
            lineWidth(2)
            strokeColor(red: 1.0, green: 0.2, blue: 0.2, alpha: 1.0)
        }
       
        lineWidth(1.0)
        pushState()
        translate(dx: position.x, dy: position.y)
        rotate(by: theta)
        pathBegin()
        pathVertex(x: 0.0, y: -r * 2.0)
        pathVertex(x: -r, y: r * 2.0)
        pathVertex(x:  r, y: r * 2.0)
        pathClose()
        pathEnd()
        popState()
    }
    
    func isDead() -> Bool {
        if energy <= 0 {
            return true
        } else {
            return false
        }
    }

}
