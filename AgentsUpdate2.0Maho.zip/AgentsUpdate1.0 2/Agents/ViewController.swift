//
//  ViewController.swift
//

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Agents"
        makeView(width: 1200.0, height: 800.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
        //scene.mouseDragged()
        //scene.mouseClicked()
    }
    
    override func mouseDown(with event: NSEvent) {
        scene.mouseClicked()
    }
    

}



class Scene: TScene {
    
    
    var vehicles: [Vehicle] = []
    var env = Environment()
    //var food = TVector2(x: random(min: 10.0, max: 30.0), y: random(min: 10.0, max: 20.0))
    var mouse = TVector2(x: tin.mouseX, y: tin.mouseY)
    
    
    
    
    override func setup() {
        env.addPoison()
        //mouseDragged()
        
        
        for _ in 1...10 {
            let v = Vehicle(x: random(max: tin.width), y: random(max: tin.height))
            vehicles.append(v)
        }
    }
    
    
    override func update() {
        background(gray: 1.0)
        
        
        //var circle = ellipse(centerX: tin.mouseX, centerY: tin.mouseY, width: 10.0, height: 10.0)

        env.render()
        
        var index = 0
        
        if tin.frameCount % 60 == 0 {
            env.addFood()
        }
        
        
        for v in vehicles {
            //v.arrive(target: mouse)
            v.run(env: env)
            if v.isDead() {
                vehicles.remove(at: index)
                index -= 1
            }
            index += 1
        }
        
        //mouseClicked()

    }
    
//    func mouseDragged() {
//        env.poison
//        //ellipse(centerX: tin.mouseX, centerY: tin.mouseY, width: 10.0, height: 10.0)
//    }
    
    func mouseClicked() {
        //env.poison
        env.addPoison()
    }

}

